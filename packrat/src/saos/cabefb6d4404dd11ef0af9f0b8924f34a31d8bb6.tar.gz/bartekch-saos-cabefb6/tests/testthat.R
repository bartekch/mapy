library(testthat)
test_check("saos")