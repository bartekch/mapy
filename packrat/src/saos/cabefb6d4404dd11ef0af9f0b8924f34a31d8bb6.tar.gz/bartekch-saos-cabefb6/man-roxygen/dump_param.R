#' @param simplify Logical. If \code{TRUE} results will be returned as 
#'   \code{data.frame}.
#' @encoding UTF-8
